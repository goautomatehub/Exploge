import React from 'react';
import { Hero } from '../components/Hero';
import { Services } from '../components/Services';
import { Projects } from '../components/Projects';
import { Features } from '../components/Features';
import { Comparison } from '../components/Comparison';
import { Pricing } from '../components/Pricing';
import { Testimonials } from '../components/Testimonials';
import { FAQ } from '../components/FAQ';
import { Contact } from '../components/Contact';
import { LogoWall } from '../components/LogoWall';
import { ToolMarquee } from '../components/ToolMarquee';
import { Stats } from '../components/Stats';
import { Process } from '../components/Process';
import { TrustedCompanies } from '../components/TrustedCompanies';

export const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <TrustedCompanies />
      <Services />
      <Projects />
      <Process />
      <Testimonials />
      <Contact />
    </>
  );
};