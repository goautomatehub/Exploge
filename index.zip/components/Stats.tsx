
import React from 'react';
import { Reveal } from './Reveal';
import { Counter } from './Counter';

const StatItem = ({ label, value, detail, delay, isNumber = true, suffix = "" }: any) => (
  <Reveal direction="up" delay={delay} className="h-full">
    <div className="p-8 bg-white border border-zinc-100 rounded-2xl group hover:shadow-lg transition-all duration-300 text-center h-full flex flex-col justify-center">
      <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-4">
        {label}
      </div>
      <div className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tighter mb-3 text-secondary">
        {isNumber ? (
          <Counter value={parseInt(value)} suffix={suffix} />
        ) : (
          value
        )}
      </div>
      <div className="text-xs font-medium text-zinc-500 uppercase tracking-wide">
        {detail}
      </div>
    </div>
  </Reveal>
);

export const Stats: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="bg-[#fafafa] border border-zinc-100 rounded-3xl p-8 md:p-16 lg:p-20 relative overflow-hidden">
          
          <div className="text-center max-w-3xl mx-auto mb-12 md:mb-16 relative z-10">
            <Reveal direction="up">
              <span className="text-[10px] font-bold text-primary uppercase tracking-widest mb-4 inline-block">Our Impact</span>
            </Reveal>
            <Reveal direction="up" delay={0.1}>
              <h3 className="text-3xl xs:text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-tighter text-secondary">
                Results That Matter.
              </h3>
            </Reveal>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10 items-stretch">
            <StatItem 
              label="TIME SAVED" 
              value="42" 
              suffix="%"
              detail="Hours saved on tasks" 
              delay={0.1} 
            />
            <StatItem 
              label="PROJECTS" 
              value="150" 
              suffix="+"
              detail="Systems we've built" 
              delay={0.2} 
            />
            <StatItem 
              label="DELIVERY" 
              value="Fast" 
              isNumber={false}
              detail="Quick turn-around" 
              delay={0.3} 
            />
            <StatItem 
              label="HAPPY CLIENTS" 
              value="98" 
              suffix="%"
              detail="Client success rate" 
              delay={0.4} 
            />
          </div>
        </div>
      </div>
    </section>
  );
};
