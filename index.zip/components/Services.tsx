import React, { useMemo } from 'react';
import { Reveal } from './Reveal';
import { motion, useMotionValue, useSpring, useMotionTemplate } from 'framer-motion';
import { 
  Briefcase, 
  Users, 
  TrendingUp, 
  Shield, 
  BarChart, 
  Layers, 
  Target, 
  CheckCircle,
  ArrowRight 
} from 'lucide-react';

interface ServiceCardProps {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  delay: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ id, title, description, icon, delay }) => {
  return (
    <Reveal direction="up" delay={delay} className="h-full">
      <a 
        href="#contact"
        className="relative group p-8 md:p-10 bg-white border border-zinc-200 flex flex-col transition-all duration-300 hover:shadow-lg hover:border-primary/30 h-full rounded-2xl overflow-hidden cursor-pointer"
      >
        <div className="relative z-10 flex items-start justify-between mb-6">
          <div className="p-4 bg-zinc-50 text-secondary group-hover:bg-primary/10 group-hover:text-primary transition-all duration-300 rounded-xl">
            {React.cloneElement(icon as React.ReactElement<any>, { size: 28, strokeWidth: 1.5 })}
          </div>
          <span className="text-[10px] font-bold text-zinc-300 tracking-widest uppercase">
            {id}
          </span>
        </div>

        <h3 className="relative z-10 text-xl font-bold text-secondary uppercase tracking-tight mb-4 leading-tight">
          {title}
        </h3>
        
        <p className="relative z-10 text-zinc-500 text-sm leading-relaxed mb-8 flex-grow font-normal">
          {description}
        </p>

        <div className="relative z-10 pt-6 border-t border-zinc-100 flex items-center justify-between">
          <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 group-hover:text-primary transition-colors">Learn More</span>
          <ArrowRight className="w-4 h-4 text-zinc-300 group-hover:text-primary group-hover:translate-x-1 transition-all" />
        </div>
      </a>
    </Reveal>
  );
};

export const Services: React.FC = () => {
  const services = useMemo(() => [
    { 
      id: "01", 
      title: "Workflow Automation", 
      icon: <Target />, 
      description: "Automate manual tasks using Zapier, Make, and n8n to save time and reduce errors." 
    },
    { 
      id: "02", 
      title: "CRM Setup", 
      icon: <Users />, 
      description: "Complete setup and customization of GoHighLevel and Closebot for your business." 
    },
    { 
      id: "03", 
      title: "Project Management", 
      icon: <Layers />, 
      description: "Organize your team's work efficiently on Monday, ClickUp, and Asana." 
    },
    { 
      id: "04", 
      title: "AI Sales Agents", 
      icon: <Briefcase />, 
      description: "Build auto-responding sales agents using Closebot and OpenAI technology." 
    },
    { 
      id: "05", 
      title: "Sales Funnels", 
      icon: <TrendingUp />, 
      description: "Create high-converting landing pages on GoHighLevel and WordPress." 
    },
    { 
      id: "06", 
      title: "App Integrations", 
      icon: <Shield />, 
      description: "Connect different apps like Stripe and Google Sheets using Pabbly and Make." 
    },
    { 
      id: "07", 
      title: "Web Development", 
      icon: <CheckCircle />, 
      description: "Build fast and responsive business websites using WordPress." 
    },
    { 
      id: "08", 
      title: "Operations Audit", 
      icon: <BarChart />, 
      description: "Review your current tools and suggest better systems for your business operations." 
    }
  ], []);

  return (
    <section id="services" className="py-24 md:py-32 bg-white relative overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16 md:mb-24">
          <Reveal direction="up">
            <div className="flex items-center justify-center gap-4 mb-4 md:mb-6">
              <span className="text-[10px] font-bold text-primary uppercase tracking-widest">Service Portfolio</span>
            </div>
          </Reveal>
          <Reveal direction="up" delay={0.1}>
            <h2 className="text-3xl xs:text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-tighter leading-[0.95] text-secondary mb-8">
              Expertise & Solutions.
            </h2>
          </Reveal>
          
          <Reveal direction="up" delay={0.2}>
            <p className="text-zinc-500 text-sm md:text-lg max-w-2xl mx-auto leading-relaxed">
              We provide the tools and expertise needed to build reliable and scalable operations for your business.
            </p>
          </Reveal>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 items-stretch">
          {services.map((service, index) => (
            <ServiceCard 
              key={service.id}
              id={service.id}
              title={service.title}
              delay={index * 0.1}
              description={service.description}
              icon={service.icon}
            />
          ))}
        </div>
      </div>
    </section>
  );  
};