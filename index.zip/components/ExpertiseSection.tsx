
import React from 'react';
import { Reveal } from './Reveal';
import { Icons } from './Icons';

export const ExpertiseSection: React.FC = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          {/* Image Side */}
          <div className="w-full lg:w-1/2 relative">
            <Reveal direction="left">
              <div className="relative">
                {/* Decorative Elements */}
                <div className="absolute -top-6 -left-6 w-32 h-32 bg-primary/10 rounded-2xl -z-10 animate-pulse"></div>
                <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-secondary/5 rounded-full -z-10"></div>
                
                {/* Main Image Container */}
                <div className="relative rounded-[2rem] overflow-hidden shadow-2xl border border-black/5 aspect-[4/3] md:aspect-[16/10] lg:aspect-square">
                  <img 
                    src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop" 
                    alt="Team working on automation strategy" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
                  />
                  
                  {/* Floating Badge */}
                  <div className="absolute bottom-8 left-8 bg-white/90 backdrop-blur-md p-6 rounded-2xl shadow-xl border border-white/20 max-w-[200px] hidden md:block">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white">
                        <Icons.Zap className="w-5 h-5" />
                      </div>
                      <span className="font-black text-sm uppercase tracking-tighter">Precision</span>
                    </div>
                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest leading-tight">
                      Engineered for 100% Reliability
                    </p>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Content Side */}
          <div className="w-full lg:w-1/2 space-y-8">
            <Reveal direction="right">
              <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-[10px] font-bold mono uppercase tracking-[0.3em] mb-4 rounded-sm">
                Our Expertise
              </div>
              <h2 className="text-3xl xs:text-4xl md:text-5xl lg:text-6xl font-black uppercase tracking-tighter leading-[0.9] mb-8 text-secondary">
                Engineering <br/> <span className="text-primary italic">Agency Freedom</span>.
              </h2>
              <p className="text-gray-500 text-base md:text-lg leading-relaxed mb-8">
                Most businesses are held back by manual processes that don't scale. We bridge the gap between complex technology and your business goals, creating seamless automations that work for you 24/7.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 border border-primary/20 rounded-lg flex items-center justify-center text-primary bg-primary/5">
                    <Icons.Workflow className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase mb-1">Custom Architecture</h4>
                    <p className="text-xs text-gray-400 leading-relaxed">Systems designed specifically for your unique agency workflows.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 border border-primary/20 rounded-lg flex items-center justify-center text-primary bg-primary/5">
                    <Icons.Cpu className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase mb-1">Seamless Integration</h4>
                    <p className="text-xs text-gray-400 leading-relaxed">Connecting your entire tech stack into one unified business engine.</p>
                  </div>
                </div>
              </div>

              <div className="pt-8">
                <a 
                  href="#contact" 
                  className="inline-flex items-center gap-4 group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-full border border-black flex items-center justify-center group-hover:bg-black group-hover:text-white transition-all">
                    <Icons.ArrowRight className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold mono uppercase tracking-widest">See our work</div>
                    <div className="text-[10px] text-gray-400 uppercase">Book a strategy session</div>
                  </div>
                </a>
              </div>
            </Reveal>
          </div>

        </div>
      </div>
    </section>
  );
};
